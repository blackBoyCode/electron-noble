var Noble = require('./lib/noble');

module.exports = function(bindings) {
  return new Noble(bindings);
};
